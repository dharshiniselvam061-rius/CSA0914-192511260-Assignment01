---
title: "Programming in Java – Assignment 1 (CO1)"
subtitle: "Design, Implement and Validate an Object-Oriented Model for a Campus Smart-Parking System"
---

|                       |                                                        |
|-----------------------|--------------------------------------------------------|
| **Name**              | `<YOUR NAME>`                                          |
| **Register number**   | `<REGISTER NUMBER>`                                    |
| **Course**            | Programming in Java (CSA09) – Assignment 1, CO1        |
| **Java version**      | OpenJDK 21 (code uses `instanceof` patterns, so Java 16+) |
| **GitHub repository** | `<https://github.com/YOUR-USERNAME/CSA09-REGISTERNUMBER-Assignment1>` |

# 0. Overview and notes on the brief

Every task has its own folder in the repository (`Task01` … `Task12`). `run_all.sh` compiles and runs everything and writes the console output of each program to an `output*.txt` file in that task's folder. All numbers quoted in this report come from those files.

Points in the PDF that needed an interpretation:

* The headings of **Task 4** (garbled in the PDF) and **Task 7** (missing) were inferred from the surrounding text: Task 4 = classes, objects and constructors; Task 7 = method overriding, `final`, and `toString/equals/hashCode`.
* For the two "Complete the Code" programs only the end of `main()` is visible in the PDF. The first lines of `main()` were reconstructed so the program prints exactly the expected output. Everything else is the given code with each `TODO` replaced.
* Pseudocode is written in a plain structured style (ALGORITHM / INPUT / OUTPUT / BEGIN / END). The SIMATS pseudocode standard was not included in the PDF, so adjust the layout to it if it differs.
* Timings are single runs on one machine with a warm-up, so they are noisy. They are used to show the *shape* of growth, not exact constants.

**Package/folder map**

| Task | Folder | Main program(s) |
|---|---|---|
| 1 | `Task01` | `Task01Demo` |
| 2 | `Task02` | `Task02Demo` |
| 3 | `Task03` | `ParkingFacility` (Complete the Code), `FeeSlabs`, `AltFacility` |
| 4 | `Task04` | `Task04Demo` |
| 5 | `Task05` | `Task05Demo` |
| 6, 8, 9 | `Task06_09_FeeDemo` | `FeeDemo` (Complete the Code), `ConstructorTrace` |
| 7 | `Task07` | `OverrideDemo` |
| 8 | `Task08` | `PolymorphismDemo` |
| 9 | `Task09` | `InterfaceDemo` |
| 10 | `Task10` | `com.campus.encaps.EncapsulationDemo` |
| 11 | `Task11` | full system, `ParkingApp`, `ParkingTests`, `StorageBench` |
| 12 | `Task12` | adapted system, `NewRequirementTests` |

# Task 1 – Understand the Problem and Identify the Objects

## Inputs and outputs

| Inputs | Outputs |
|---|---|
| Vehicle type (two-wheeler, car, EV) and registration number | Parking ticket: unique ticket number, slot (floor, slot), entry time |
| User category (student, staff, visitor) and pass (none, monthly) | Fee on exit: parking fee, plus charging fee for EVs |
| Entry time and exit time | Facility status (slots in use) |
| Energy used for charging (kWh) | Rejection messages (full, duplicate, unknown type, unknown ticket) |
| Facility layout: slots on each floor | |

## Business rules

1. A slot holds at most one vehicle at a time.
2. A ticket number is unique and never reused, even after the vehicle leaves.
3. A registration number can have only one active ticket (no duplicate parking).
4. A slot is allocated on entry and released on exit; a released slot can be reused.
5. Fee = vehicle's hourly rate × started hours (every started hour is charged in full), capped per day.
6. Students and staff with a valid monthly pass park free; visitors always pay.
7. EV charging is charged separately (per kWh) and is never waived by a pass.
8. Exit time must not be before entry time; a failed exit must leave the vehicle parked.
9. A rejected operation must not change the state of the system.

## Assumptions

* Any slot suits any vehicle; the first free slot (lowest floor, then lowest slot) is allocated.
* Rates (Rs per started hour): two-wheeler 10, car 30, EV 40; charging Rs 9 per kWh; daily cap = 8 hours' worth of the hourly rate per 24 h.
* Registration numbers are case-insensitive and unique per physical vehicle.
* A stay of 0 minutes costs Rs 0.
* The facility shapes considered are 1×20, 3×50, 5×100 slots, and later 5 floors with different sizes.

## Candidate classes and why each is needed

| Class | Responsibility | Why it is needed |
|---|---|---|
| `Vehicle` (abstract) + `TwoWheeler`, `Car`, `ElectricCar` | Identity (reg. no.) and its own hourly rate/fee | Fee differs by type; one class per type lets the fee be overridden instead of tested with `if` |
| `Chargeable` (interface) | Capability "can be charged" | Only EVs have it; a capability, not a kind of vehicle |
| `ParkingTicket` | Record of one stay: number, vehicle, slot, user, pass, entry time | Needed to compute the fee later; immutable so it cannot be corrupted |
| `ParkingFacility` | Floors and slots; allocate and release | Owns rule 1 (one vehicle per slot) |
| `ParkingLot` | Entry and exit workflow, active tickets | Coordinates facility, tickets and fee; owns rules 3, 8, 9 |
| `FeePolicy` | Who pays what (waivers, passes) | Keeps pricing rules in one place |
| `UserType`, `PassType` (enums) | Fixed sets of values | Prevent invalid strings such as "studnet" |
| `VehicleFactory` | Creates a vehicle from text | Rejects unknown types in one place |
| `ParkingException` | Business-rule violation | Distinguishes "rule broken" from programming errors |
| `ParkingApp` | Reads commands with `Scanner` | Input/output only, no rules |

## Alternative concept and complexity analysis – parallel arrays

*Design in use:* each vehicle is an object (`VehicleRec{regNo, type, entryTime}`) stored in one array. *Alternative:* `String[] regNo`, `String[] type`, `long[] entryTime`, where index *i* of each array describes the same vehicle.

```java
int find(String reg) {                 // parallel arrays
    for (int i = 0; i < n; i++) if (regNo[i].equals(reg)) return i;
    return -1;
}
```

| | Objects | Parallel arrays |
|---|---|---|
| Find by registration number | O(n) – scan, compare `v[i].regNo` | O(n) – scan `regNo[]` |
| Add an attribute (e.g. `ownerName`) | add one field to the class | add a new array and change **every** place that inserts, removes, shifts or sorts, or the arrays go out of step |
| Space per vehicle | one object (header + fields ≈ 32 bytes with compressed references) + 1 reference in the array | 3 slots (≈ 4 + 4 + 8 bytes) – both Θ(1) per vehicle, Θ(n) overall |

Measured worst-case search (`Task01/output.txt`, ns per search):

| n | objects | parallel arrays |
|---|---|---|
| 1,000 | 9,244 | 4,079 |
| 10,000 | 26,167 | 21,759 |
| 100,000 | 809,502 | 738,318 |

Both grow roughly linearly with n (confirming O(n)). The parallel-array version is a little faster because it reads one contiguous array instead of following a reference to each object. The object design costs a constant factor, but it keeps each vehicle's data together and makes adding an attribute a one-class change, which is what the Design Challenge requires.

# Task 2 – Choose the Data Representation

| Field | Type | Reason |
|---|---|---|
| Floor and slot number | `int` | Small, whole, used as array indexes |
| Vehicle number | `String` | Alphanumeric (e.g. `TN01AB1234`); normalised to upper case |
| Entry/exit time | `LocalDateTime` | Calendar-aware; avoids hand-written clock arithmetic across midnight |
| Duration | `int` minutes | Never negative; `int` holds about 4,000 years of minutes |
| Fee | `double` | Rates may be fractional (e.g. 12.5); *a production system would use `BigDecimal` or whole paise to avoid binary rounding* |
| Ticket number | `long` | A counter that must never wrap around |
| Slot map | `String[][]` jagged array | One row per floor, each row its own length |

**Input** is read with `Scanner` (`ParkingApp` reads command lines; `Task02Demo` reads minutes and rate) or from command-line arguments (`java Task02Demo 130 30`). Both give the same result (`Task02/output.txt`, `output_scanner.txt`).

## Casting / integer-division risk

For a 130-minute stay at Rs 30/hour the correct fee is 3 started hours × 30 = **Rs 90**.

| Code | Result | Problem |
|---|---|---|
| `int hours = minutes / 60; hours * rate` | **60.0** | Integer division gives 2; the third started hour is lost |
| `(double)(minutes / 60) * rate` | **60.0** | The cast is applied *after* the division, so it changes nothing |
| `hours * (int) rate` with rate 12.5 | 36.0 instead of 37.5 | `(int)` truncates the fractional rate |
| `hours = (minutes + 59) / 60; hours * rate` | **90.0** | Correct: integer ceiling, rate stays `double` |

The design therefore computes the ceiling with integer arithmetic only (`(minutes + 59) / 60`) and keeps the rate as `double`.

## Alternative concept – 1-D array or `ArrayList<String[]>` for slots

* **1-D array:** index = floor × slotsPerFloor + slot works **only if every floor has the same size**. With floors {30, 50, 40, 60, 20} the formula points at the wrong cell (`Task02/output.txt`: index 149 is `null` while the vehicle is at index 179). The fix is an offset array (prefix sums): index = offset[floor] + slot.
* **`ArrayList<String[]>`:** one `String[]` per floor, so unequal floors work and a new floor can be added at run time.

| | Jagged `String[][]` | 1-D + offsets | `ArrayList<String[]>` |
|---|---|---|---|
| Locate a slot | O(1) | O(1) (O(1) lookup in `offset[]`; building offsets is O(F)) | O(1) (`get(f)` then index) |
| Space | F row headers + all slots | 1 header + all slots + (F+1) ints | list object + backing array of F references + all rows |
| Unequal floors | natural | needs the offset table | natural |
| Adding a floor | rebuild the outer array O(F) | rebuild everything O(total) | O(1) amortised |

All three need Θ(total slots) space. The jagged array was chosen because it is the simplest correct structure for unequal floors and needs no extra bookkeeping.

# Task 3 – Design the Control Logic

**Allocation:** two nested loops – the outer loop walks floors, the inner loop walks slots. The first `null` slot is filled and `{floor, slot}` is returned immediately, so the **search stops at the first free slot**. If both loops end without finding one, the facility is full and `null` is returned.

**Fee slabs** (assumption for this task: first started hour Rs 20, each further started hour Rs 10, daily maximum Rs 100): expressed with an `if / else if / else` chain on the number of started hours (`FeeSlabs.fee`) and a `switch` on the vehicle type for the hourly rate (`FeeSlabs.ratePerHour`).

## Pseudocode

```
ALGORITHM AllocateSlot
INPUT   vehicleNo : text; slots : 2-D array (floor x slot) of text, empty = free
OUTPUT  (floor, slot) of the allocated slot, or NULL when the facility is full
BEGIN
    IF vehicleNo is NULL THEN raise error
    FOR floor <- 0 TO numberOfFloors - 1 DO
        FOR slot <- 0 TO slotsOnFloor(floor) - 1 DO
            IF slots[floor][slot] is empty THEN
                slots[floor][slot] <- vehicleNo
                RETURN (floor, slot)            // search stops here
            END IF
        END FOR
    END FOR
    RETURN NULL                                 // no free slot anywhere
END
```

```
ALGORITHM ComputeFee
INPUT   minutes : integer >= 0
OUTPUT  fee : integer
CONSTANT FIRST = 20, EXTRA = 10, DAILYMAX = 100, MINPERDAY = 1440
BEGIN
    IF minutes < 0 THEN raise error
    days  <- minutes DIV MINPERDAY
    rem   <- minutes MOD MINPERDAY
    hours <- (rem + 59) DIV 60                  // ceiling, integer arithmetic
    IF hours = 0 THEN        last <- 0
    ELSE IF hours = 1 THEN   last <- FIRST
    ELSE                     last <- FIRST + (hours - 1) * EXTRA
    END IF
    IF last > DAILYMAX THEN last <- DAILYMAX
    RETURN days * DAILYMAX + last
END
```

`FeeSlabs` output (`Task03/output_feeslabs.txt`) shows the boundaries: 60 min → Rs 20, 61 min → Rs 30, 600 min → Rs 100 (cap), 1441 min → Rs 120.

## Complete the Code result

`ParkingFacility` prints exactly the expected output (`Task03/output_facility.txt`):

```
[0, 0]
[0, 1]
[1, 0]
null
true false false
[0, 1]
```

## Alternative concept – free-slot count per floor and a stack of free slots

*Logic:* keep `freeCount[f]` and a stack of free slot numbers per floor. `allocate` finds the first floor with `freeCount > 0` and pops a slot; `release` pushes the slot back and increments the count.

| | Scan (used) | Counts + stack |
|---|---|---|
| `allocate()` time | worst case O(F·S) (full except last cell); best case O(1) | O(F) to find a floor + O(1) pop |
| `release()` time | O(1) | O(1) push |
| Extra space | O(1) | O(F) counts + O(F·S) stack entries |
| Slot given | always the lowest free slot | the most recently freed slot first |

Measured worst-case `allocate`+`release` with one slot left (`Task03/output_alt.txt`, ns):

| Layout | Scan | Counts + stack |
|---|---|---|
| 1 × 20 | 38 | 25 |
| 3 × 50 | 77 | 49 |
| 5 × 100 | 172 | 23 |

The scan grows with the number of cells (20 → 150 → 500); the stack version stays almost flat. The scan was kept because the facility is small (≤ 500 slots), it needs no extra memory or bookkeeping to keep in step, and "lowest free slot first" is predictable for drivers.

# Task 4 – Design Classes, Objects and Constructors

`ParkingTicket` (`Task11/.../model/ParkingTicket.java`; a standalone version is in `Task04/Task04Demo.java`):

* **Three overloaded constructors, chained with `this(...)`:** `(vehicle, floor, slot)` → `(vehicle, floor, slot, user, pass)` → `(vehicle, floor, slot, user, pass, entryTime)`. All validation and field assignment live in the last one, so there is no duplicated code.
* **Why:** the gate usually only knows the vehicle and the allocated slot, so shorter constructors supply sensible defaults (visitor, no pass, now); tests pass an explicit time.
* **`this`** refers to the object being built (`this.floor = floor`) and `this(...)` calls another constructor of the same class.
* Fields are `final` and there are no setters, so a ticket is **valid from the moment it exists** and cannot change later. The ticket number is taken from a static counter only after validation passes, so a rejected ticket does not burn a number.

Constructor chaining trace (`Task04/output.txt`): `new ParkingTicket("TN01AB1234", 0, 3)` runs the 3-argument constructor, which immediately calls the 4-argument one, which assigns the fields.

## Alternative concept – default constructor + setters, or static factory

* **Setters:** `new MutableTicket(); t.setRegNo(..); t.setPos(..); t.setEntry(..)`. A caller can forget a call, leaving a half-built object (the demo creates one with `floor = -1` and `entryTime = null`). Validity can only be checked later, at every use.
* **Static factory:** `FactoryTicket.of(reg, floor, slot)` with a private constructor. The validity guarantee is the same as a constructor, and the method has a descriptive name and can return a cached object; the cost is that subclasses cannot be created through it.

| n tickets (ms, `Task04/output.txt`) | chained constructor | default + setters | factory |
|---|---|---|---|
| 100,000 | 11 | 1 | 2 |
| 1,000,000 | 17 | 16 | 5 |
| 5,000,000 | 45 | 28 | 71 |

All three are O(n) time for n objects and O(1) extra space per object (one object each). The measured differences are small and inconsistent (JIT warm-up and garbage collection dominate), so they do not decide the design. The decision rests on validity: constructors and factories guarantee it, setters do not.

# Task 5 – Apply static Members and the Object Life Cycle

* **Static variables:** `ParkingTicket.counter` (ticket numbers) and the total occupancy. They belong to the class as a whole. An instance variable would be wrong: every ticket would start counting from 0 and receive number 1 (`Task05/output.txt`: "instance counter → numbers 1, 1 (duplicates!)"), breaking the "never reused" rule.
* **Static block:** runs once when the class is loaded – used for one-time set-up (rate table, first ticket number) before any object exists.
* **Static methods:** utilities that need no object, e.g. `ceilHours(int minutes)`; `VehicleFactory.create(...)`.
* **After the vehicle leaves:** `ParkingLot.exit` removes the ticket from the active array and sets the vacated cell to `null`. Once no variable refers to the ticket it is **eligible for garbage collection**; the JVM frees it at some later time. (`Task05Demo` uses a `WeakReference` to show the ticket was collected; `System.gc()` is only a request, so the guarantee is *eligibility*, not the moment.)
* **Passing and returning objects:** Java passes references **by value**. A method can change the object a reference points to (the demo's `rename` changes `holder[0]`), but reassigning the parameter inside the method does not change the caller's variable. `ParkingLot.enter` returns the new ticket object; `ParkingFacility.allocate` returns a new `int[]`.

## Alternative concept
The brief gives no alternative for this task. The sensible alternative to a static counter is a counter held by one `ParkingLot` object (an instance field). It also gives unique numbers *per lot*, but two lots would issue the same numbers, and a `ticketNo` is only unique campus-wide with a shared static (or database) counter. Both are O(1) time and O(1) space per ticket.

# Task 6 – Design the Inheritance Hierarchy

![Vehicle hierarchy (dashed = added in Task 12)](docs/uml_vehicle_hierarchy.png)

* **Superclass:** abstract `Vehicle`. **Subclasses:** `TwoWheeler`, `Car`, `ElectricCar` (later `EBike`, `DeliveryVan`). Type of inheritance: **hierarchical** (several subclasses of one superclass, one level deep). `ElectricCar` also implements the `Chargeable` interface.
* **Inherited:** `regNo`, `getRegNo()`, `calculateFee(minutes)`, `equals`, `hashCode`, `toString`. **Added in subclasses:** the hourly rate (`ratePerHour()`), and for `ElectricCar` `chargingFee(kWh)`.
* **Use of `super`:** each subclass constructor calls `super(regNo)` so that the validated, `final` `regNo` is set in one place; `super.calculateFee(minutes)` is used where a subclass extends the base rule (`Bus` in Task 7, `DeliveryVan`).
* **Users (student/staff/visitor):** no hierarchy. They differ only by one rule (who is waived), which is data, not behaviour, so an enum (`UserType`) plus `FeePolicy` is simpler than three subclasses.

## Constructor execution order for `new ElectricCar("TN03C3")`
(`Task06_09_FeeDemo/output_constructor_trace.txt`)

```
1. new ElectricCar("TN03C3") called; Object() runs first (implicit)
2. Vehicle instance initialiser runs
3. Vehicle constructor body: regNo = TN03C3
4. ElectricCar instance initialiser runs, rate field = 40.0
5. ElectricCar constructor body finished
```
Order: `Object` → `Vehicle` → `ElectricCar`; the superclass is always built first. Note step 3: when `Vehicle`'s constructor calls the overridden `ratePerHour()`, the subclass field is still `0.0` – so constructors should not call overridable methods.

## Alternative concept – composition (`Vehicle` has-a `VehicleType` with the rate)

```java
class VehicleType { final String name; final double rate; }
class Vehicle { String regNo; VehicleType type;
    double calculateFee(int m) { return ((m + 59) / 60) * type.rate; } }
```
A new type is a new `VehicleType` *object* (data), with no new class. But type-specific behaviour (EV charging, van peak hours) has no natural home: it needs flags or `if` statements again, or a second hierarchy. Time per fee is O(1) in both designs (composition has one extra reference hop). Space per vehicle: composition adds one reference (≈ 4–8 bytes); the shared `VehicleType` objects are created once per type. Inheritance was chosen because the types genuinely differ in *behaviour* (flat fee, time-based fee, charging), and "is-a" fits.

# Task 7 – Method Overriding, `final`, and Object-class methods

* **Overridden:** `ratePerHour()` (abstract in `Vehicle`, implemented by each subclass); `calculateFee()` in `EBike` and `DeliveryVan` where the rule differs; `equals`, `hashCode`, `toString` from `Object`. The subclass version is needed because the *rule* differs by type, while the call site stays the same.
* **`@Override`:** makes the compiler check that a method really overrides something – a misspelt name or wrong parameter list becomes a compile error. **Rules:** same name and parameter list; return type the same (or a subtype); access not narrower (`public` cannot become package-private); no new broader checked exceptions. (`OverrideDemo` lists the two compile errors in comments.)
* **`final`:** `regNo` (a vehicle's identity never changes), `getRegNo()` (subclasses must not change how identity is read), `ParkingTicket` as a `final class` (an immutable record that cannot be subclassed and altered), `Money` in `OverrideDemo`.
* **`equals` / `hashCode` / `toString`:** `equals` compares only the registration number (`o instanceof Vehicle && regNo.equals(...)`); `hashCode` uses `regNo.hashCode()`, so equal objects have equal hash codes and work in `HashSet`/`HashMap` (`OverrideDemo`: "HashSet contains equal object? true"); `toString` prints `Car[TN01A1]`.

## Alternative concept – one `calculateFee()` with a `switch` on a type field

```java
double calculateFee(int m) {
    int h = (m + 59) / 60;
    switch (type) { case TWO_WHEELER: return h*10; case CAR: return h*30; case EV: return h*40; }
}
```
* Time per fee for k types: a `switch` on small integer constants is compiled to a jump table, so O(1) in practice (a long `if-else` chain would be O(k)).
* Adding a type means editing this method and the `type` enum – **at least 2 existing places change** (and `Vehicle` is retested) – versus **0 existing classes** with overriding (only a new subclass). The `switch` also scatters pricing rules for several types into one method that grows with every type.

# Task 8 – Apply Polymorphism

* **Compile-time polymorphism (overloading):** `Vehicle.fee(int)` and `fee(int, double discount)` in `PolymorphismDemo` – the compiler chooses the version from the argument list. Also `calculateFee(int)` vs `calculateFee(LocalDateTime, LocalDateTime)` in Task 12.
* **Runtime polymorphism (overriding):** a `Vehicle[]` can hold any subclass, and `v.calculateFee(...)` runs the version belonging to the **actual** object. `ParkingLot` and `FeePolicy` never test the vehicle type, so there is no `if (type == ...)` chain; adding a vehicle type does not touch them.

## Trace of one call through dynamic dispatch
`Vehicle v = new ElectricCar("TN03C3"); double fee = v.calculateFee(130);`

1. *Declared type:* `Vehicle` – the compiler only checks that `Vehicle` has `calculateFee(int)`.
2. *Actual type:* `ElectricCar` – found by the JVM at run time.
3. `ElectricCar` does not override `calculateFee`, so `Vehicle.calculateFee` runs; inside it, the call `ratePerHour()` is dispatched again on the actual object and runs **`ElectricCar.ratePerHour()`** (returns 40). Result: 3 hours × 40 = 120.

## Why the last line of `FeeDemo` prints `true`
`new Car("TN02B2").equals(new ElectricCar("TN02B2"))` calls `Vehicle.equals`, which checks `instanceof Vehicle` and compares only the registration numbers – not the class. Both are `Vehicle`s with the same number, so the result is `true`. **This is the correct behaviour for this system:** a registration number identifies one physical vehicle, so one number cannot be both a car and an EV, and the duplicate-parking rule depends on it. If equality compared classes too, the same registration number entered as "Car" and again as "ElectricCar" would wrongly be accepted as two vehicles.

## Complete the Code result (`Task06_09_FeeDemo/output.txt`)
```
TwoWheeler TN01A1 -> Rs 30.0
Car TN02B2 -> Rs 90.0
ElectricCar TN03C3 -> Rs 210.0
true
```
(130 min = 3 started hours: 3×10, 3×30, 3×40 + 10 kWh × 9 = 210.)

## Alternative concept – `instanceof` checks and casts
```java
if (v instanceof TwoWheeler) ... else if (v instanceof Car) ... else if (v instanceof ElectricCar) ...
```
Dynamic dispatch is O(1) per call; an `instanceof` chain is up to k checks, O(k). Code size grows with k and every new type edits the chain (maintenance cost). Measured for k = 3 (`Task08/output.txt`, 30 million calls, ns per call): dispatch 3.55, `instanceof` 1.12, `switch` 1.17. **At k = 3 the chain was actually faster** – the JIT compiler inlines a short, predictable chain, while a call site seeing three different classes is a megamorphic virtual call. The O(1) vs O(k) difference only matters for large k; the real benefit of dispatch is that adding a type touches no existing code, not raw speed.

# Task 9 – Abstraction: abstract classes and interfaces

* **Interface:** `Chargeable` (capability of EVs). `InterfaceDemo` adds `Payable` (a fee-paying user/vehicle) to show a default and a static method.
* **Abstract class:** `Vehicle` – it has **state** (`regNo`), a **constructor** with validation, shared code (`calculateFee`, `equals`) and an abstract part (`ratePerHour`). An interface cannot hold per-object state or constructors.
* **Why both:** "is a kind of" with shared state → abstract class. "Can do" across unrelated things → interface; a charging socket is not a vehicle but can still implement `Chargeable` (`WallSocket` in `InterfaceDemo`).
* **Multiple behaviours:** a class has only one superclass but can implement many interfaces – `ElectricCar extends Vehicle implements Chargeable, Payable`.
* **Default/static methods:** a `default` method adds behaviour to an interface without breaking existing implementers (`Payable.receipt()` built on `amountDue()`); a `static` method is a helper tied to the interface (`Payable.withGst(...)`).

## Alternative concept – `Vehicle` as an interface, `Chargeable` as an abstract class
* *Cannot be expressed:* a **private `final regNo` field and constructor** in `Vehicle` (interface fields are public static constants), so each class would re-declare `regNo`, validation and `equals`; `equals`/`hashCode` cannot be given as default methods at all (interfaces cannot override `Object` methods).
* `ElectricCar extends Chargeable` would use up its single superclass, so it could no longer extend anything else; **multiple inheritance of type** is only possible with interfaces.
* Time per call: virtual vs interface call – both effectively O(1) after JIT, with at most a small constant difference. Space per object: the same one `regNo` reference, but declared (and kept consistent) in every class instead of once.

# Task 10 – Encapsulation through Packages and Access Modifiers

**Package structure**
```
com.campus.parking.model     Vehicle, TwoWheeler, Car, ElectricCar, Chargeable, ParkingTicket, UserType, PassType
com.campus.parking.service   ParkingFacility, ParkingLot, FeePolicy, VehicleFactory, ParkingException
com.campus.parking.app       ParkingApp
com.campus.encaps            Slot, EncapsulationDemo  (Task 10 demo of access levels)
```

| Modifier | Where used | Why |
|---|---|---|
| `private` | all fields (`regNo`, `slots`, `active`, …) | Only the class itself can change its data |
| `protected` | `Vehicle` constructor, `ratePerHour()` | Only subclasses may call/implement it – not other packages |
| package-private | `Slot.describe()` | Helper visible only inside `com.campus.encaps` |
| `public` | the operations other packages need: `enter`, `exit`, getters | The smallest possible public surface |

Validated setters/constructors: `Slot.setNumber(-3)` is rejected, `park` refuses a second vehicle (`Task10/output.txt`: "blocked: slot already holds TN01A1").

**Wrapper classes and autoboxing:** `List<Integer>` and `Map<String, Function<…>>` hold wrapper objects, so `int` values are boxed automatically. Risks demonstrated: `Integer 127 == 127` is `true` but `128 == 128` is `false` (the `==` compares references; only small values are cached) – use `equals`; unboxing a `null` throws `NullPointerException`; `list.remove(Integer.valueOf(10))` vs `list.remove(0)` mean different things.

## Alternative concept – public fields, validation in the calling code
`OpenSlot` in the demo shows what goes wrong: `o.number = -3; o.vehicleNo = "";` is accepted silently. Validation per update is O(1) either way, but with public fields the same check must be repeated **at every place that writes the field** (N call sites, any of which can forget it), whereas with a private field and a setter it exists in **one** place. A later rule change (for example a maximum slot number) is one edit versus N edits.

# Task 11 – Implement, Test and Defend the Design

The complete system is in `Task11/`: UML below, source under `src/`, a Scanner-driven program (`ParkingApp`, input file `input/commands.txt`, output `output_app.txt`) and the test table (`output_tests.txt`).

![System classes (T12 marks what Task 12 added or changed)](docs/uml_system_classes.png)

Sample run (`Task11/output_app.txt`): three vehicles enter (floor 0 slots 0 and 1, floor 1 slot 0); the fourth is rejected because the facility is full; a duplicate registration number and an unknown vehicle type are rejected; exits cost Rs 30 (two-wheeler, 130 min), Rs 0 (student with monthly pass), Rs 210 (EV, 130 min + 10 kWh); exiting twice is rejected.

## Test table – 43 tests, all pass (`Task11/output_tests.txt`)

| ID | Test case | Expected | Actual | Result |
|---|---|---|---|---|
| N1 | Two-wheeler, 130 min | 30.0 | 30.0 | PASS |
| N2 | Car, 130 min | 90.0 | 90.0 | PASS |
| N3 | EV, 130 min + 10 kWh | 210.0 | 210.0 | PASS |
| N4/N5 | Student / staff with monthly pass | 0.0 | 0.0 | PASS |
| N6 | Visitor with monthly pass pays (car, 60 min) | 30.0 | 30.0 | PASS |
| N7 | Staff + pass, EV, 5 kWh: only charging | 45.0 | 45.0 | PASS |
| N8 | Student, no pass, 61 min | 60.0 | 60.0 | PASS |
| B1 | Zero-minute parking | 0.0 | 0.0 | PASS |
| B2 / B3 | 60 min / 61 min (fee-slab boundary) | 30.0 / 60.0 | 30.0 / 60.0 | PASS |
| B4 | 1 minute = 1 started hour | 30.0 | 30.0 | PASS |
| B5 / B6 | 480 min / 481 min (daily cap) | 240.0 / 240.0 | 240.0 / 240.0 | PASS |
| B7 / B8 | 1440 min / 1441 min | 240.0 / 270.0 | 240.0 / 270.0 | PASS |
| B9 | EV with 0 kWh: no charging fee | 40.0 | 40.0 | PASS |
| S1 | Last free slot is allocated | [0,0] | [0,0] | PASS |
| S2 | Entry when full | ParkingException | ParkingException | PASS |
| S3 | Slot reusable after exit | ok | ok | PASS |
| S4 | Slots filled floor by floor | [0,0][0,1][1,0] | [0,0][0,1][1,0] | PASS |
| S5 / S7 | Ticket numbers increasing, never reused | true | true | PASS |
| S6 | Freed slot [0,1] reused | [0,1] | [0,1] | PASS |
| S8 | Active count after 4 entries, 1 exit | 3 | 3 | PASS |
| I1 / I2 | Unknown / null vehicle type | IllegalArgumentException | IllegalArgumentException | PASS |
| I3 | Blank registration number | IllegalArgumentException | IllegalArgumentException | PASS |
| I4 / I5 | Duplicate registration (case-insensitive); no slot used | ParkingException; 1 | ParkingException; 1 | PASS |
| I6–I9 | `release` of invalid floor, negative floor, invalid slot, already-free slot | false | false | PASS |
| I10 | Exit of unknown vehicle | ParkingException | ParkingException | PASS |
| I11 / I12 | Exit before entry; vehicle stays parked | IllegalArgumentException; 1 | IllegalArgumentException; 1 | PASS |
| I13–I15 | Negative minutes; zero-size floor; negative kWh | IllegalArgumentException | IllegalArgumentException | PASS |
| O1–O3 | `equals`/`hashCode` by registration number | true / true / false | true / true / false | PASS |

## Evaluation of the design (from the evidence)
* **Correct:** all 43 tests pass, including every boundary and invalid case the brief lists; a rejected operation never changes state (I5, I12).
* **Fee rules** live in `Vehicle.calculateFee` (per type) and `FeePolicy` (who pays); allocation rules live only in `ParkingFacility`.
* **Weak point – exit lookup is O(n):** `ParkingLot.exit` scans the active array. The benchmark below shows it grows linearly, but with at most 500 slots the cost stays below a microsecond-scale scan, so it is acceptable now and easy to replace later because the scan is hidden inside one private method (`indexOf`).
* **Other limits:** `double` is used for money (see Task 2); `ParkingTicket.counter` is lost on restart (a real system would persist it); the classes are not thread-safe.

## Alternative concept – `ArrayList<ParkingTicket>` or `HashMap<String, ParkingTicket>` for active tickets
Exit processing with a `HashMap` is `map.remove(regNo)` (O(1) average) instead of scan-then-compact; with an `ArrayList`, find is a scan and `remove(index)` shifts elements (O(n)). Measured time to find a ticket (`Task11/output_bench.txt`, ns per lookup):

| n parked | array | ArrayList | HashMap |
|---|---|---|---|
| 100 | 123 | 156 | 6 |
| 1,000 | 1,459 | 1,920 | 60 |
| 10,000 | 15,362 | 17,922 | 85 |
| 50,000 | 183,104 | 180,581 | 134 |

Array and `ArrayList` grow about 10× per 10× in n (O(n)); the `HashMap` stays nearly flat (O(1) average). Space for n tickets: the array holds n references (≈ 4 bytes each); `ArrayList` the same plus spare capacity; `HashMap` also needs an entry object per ticket and a table, roughly 32–48 extra bytes per ticket – more memory for much faster lookups. **Recommendation:** keep the array for a campus of ≤ 500 slots (simple, tiny), but switch to a `HashMap` if the facility grows by two orders of magnitude.

# Task 12 – Re-evaluate and Adapt the Design (Day-4 Design Challenge)

**Changed requirements:** (1) e-bikes with a flat fee; (2) delivery vans at double the car rate from 9 AM to 5 PM; (3) a one-day visitor pass; (4) five floors with different slot counts.

## A. Impact analysis

* **Different slot count per floor:** the design already uses a jagged array (`String[][]`, Task 2), so floors of any size need **no code change** – only the constructor argument `{30, 50, 40, 60, 20}`. A single `slotsPerFloor` value or a formula-based 1-D array would have broken (Task 2 showed index 149 instead of 179).
* **E-bike (flat fee):** new subclass; the flat fee overrides `calculateFee`.
* **Delivery van:** the fee depends on the *time of day*, but `calculateFee(int minutes)` only knows the duration. This is the one real gap in the original design: the fee API needs the entry/exit times.
* **One-day pass:** a new value for `PassType` and a new rule in `FeePolicy`.
* **Classes that must be modified rather than extended:** `Vehicle` (one new method), `PassType` (one new constant), `FeePolicy` (day-pass rule and time-aware call), `VehicleFactory` (new types). **Unchanged:** `ParkingLot`, `ParkingFacility`, `ParkingTicket`, `TwoWheeler`, `Car`, `ElectricCar`, `Chargeable`, `UserType`, `ParkingException`, `ParkingApp`.

## B. Evaluation of the original design

* *Can new vehicle types be added only by writing new subclasses?* Mostly yes: `EBike` and `DeliveryVan` are new subclasses, and no `if/switch` on type exists in the fee code. Two exceptions: `VehicleFactory` used a `switch` over type names (one line per type edited into an existing class), and the fee signature lacked time information.
* *Are the pricing rules in one place or spread?* Per-vehicle rates are in each subclass; "who pays" rules are all in `FeePolicy`. So a *waiver/pass* rule changes one class, while a *rate* rule changes one subclass.
* *Can the existing tested classes remain unchanged?* The three core classes `ParkingLot`, `ParkingFacility` and `ParkingTicket`, and the three original vehicle classes, remain unchanged – the 43 Task 11 tests are the evidence (below). Four classes needed small edits.

## C. Decision: MODIFY (keep the design, adapt it in four places)
A full redesign was not justified: the evidence shows 10 of 14 files unchanged. Retaining it unchanged was not possible because of the time-dependent van fee.

| Change | Kind | Detail |
|---|---|---|
| `EBike` | new class | flat Rs 20 per visit (0 min = Rs 0) |
| `DeliveryVan` | new class | each started hour costs 2 × car rate if the hour starts between 09:00 and 17:00, else the car rate; cap per started day |
| `Vehicle` | modified (additive) | new `calculateFee(LocalDateTime in, LocalDateTime out)` whose default calls the old method, so existing subclasses behave as before |
| `PassType` | modified | + `DAY` |
| `FeePolicy` | modified | day pass: visitor pays Rs 100 per started 24 h; otherwise calls the time-aware fee |
| `VehicleFactory` | modified (redesigned) | `switch` replaced by a registry (`register(type, constructor)`), so future types need one line and no edit to existing logic |

`diff -rq Task11/src Task12/src` lists exactly these 4 modified and 2 new files.

**Assumptions:** day pass = flat Rs 100 for each started 24 h, for visitors only (students/staff are unaffected); flat e-bike fee is per visit; the van's "peak" is decided by the hour in which each billable hour *starts*; `calculateFee(int)` for a van, which has no times, assumes the worst case (all peak).

## Test results for the new categories (`Task12/output_new_tests.txt`) – 39 tests, all pass

| Group | Tests | Highlights |
|---|---|---|
| E-bike | E1–E5 | 10 min, 500 min and 1441 min all Rs 20; 0 min Rs 0; student + monthly pass free |
| Delivery van | V1–V13 | 10:00–12:10 → 180; 08:30–10:30 → 90 (mixed); 17:00–18:00 → 30 (starts exactly at 17:00 = off-peak); 09:00–10:00 → 60 (starts exactly at 09:00 = peak); 22:00–01:00 → 90; 09:00–19:00 capped at 480; car unchanged (90) |
| Day pass | P1–P7 | 10 h → 100; exactly 24 h → 100; 24 h 1 min → 200; EV with 10 kWh → 100 + 90; student with a day pass pays normally |
| 5 uneven floors | F1–F9 | capacity 200; 31st vehicle at [1,0], 81st at [2,0], 121st at [3,0], 181st at [4,0], 200th (last free) at [4,19]; 201st rejected |
| Factory / future | X1–X5 | `ebike`, `DeliveryVan` created; unknown type still rejected |

**Regression:** the unchanged `ParkingTests` from Task 11 were compiled against the Task 12 source: **43 of 43 pass** (`Task12/output_regression_task11_tests.txt`), i.e. the existing behaviour was not broken.

## Ease of adding a further vehicle type
Test X4 adds a `Truck` (Rs 100/hour) with **one new class and one `VehicleFactory.register("TRUCK", Truck::new)` line, with no edit to any existing class**; a 60-minute stay costs Rs 100 as expected. Compared with the original design, which needed a new `case` inside `VehicleFactory`, this removes the last place where a type name was hard-coded.

## Trade-offs
* `EBike.ratePerHour()` returns 0 because it has no hourly rate – a small smell caused by `ratePerHour()` being abstract in `Vehicle`; the alternative (a `PricingRule` strategy object per vehicle) would be cleaner but would rewrite every vehicle class, which the challenge forbids.
* The registry is static mutable state shared by the whole program and is not thread-safe; acceptable for a single-threaded gate program, to be replaced by an injected registry otherwise.
* `Vehicle` gained a second `calculateFee` overload; the benefit (no change in `ParkingLot` or in the three original vehicle types) outweighs the extra method.

**Final decision:** MODIFY. The decision follows from the evidence: jagged arrays absorb the facility change at no cost; new vehicle types are new subclasses; only the time-dependent van fee required changing the fee API, and that was made additively. 43/43 regression tests and 39/39 new tests support it.

# Reproducing the results

```
./run_all.sh          # compiles every task and rewrites all output*.txt files
```
Requires JDK 17 or later (tested with 21). Each task's `output*.txt` is the saved console output; take your own screenshots of the same runs for the submission.
