#!/usr/bin/env bash
# Compiles and runs every task, saving the console output to <Task>/output.txt.
# Usage: ./run_all.sh        (needs JDK 17+; tested with JDK 21)
set -u
cd "$(dirname "$0")"
unset JAVA_TOOL_OPTIONS         # keep environment banners out of saved outputs

run() {  # run <task-dir> <out-file> <command...>
  local dir="$1" out="$2"; shift 2
  ( cd "$dir" && "$@" ) > "$dir/$out" 2>&1
  echo "== $dir -> $dir/$out (exit $?)"
}

mkdir -p build
for t in Task01 Task02 Task03 Task04 Task05 Task07 Task08 Task09 Task06_09_FeeDemo; do
  rm -rf "build/$t"; mkdir -p "build/$t"; javac -d "build/$t" $t/*.java || exit 1
done
rm -rf build/Task10; mkdir -p build/Task10; javac -d build/Task10 $(find Task10/src -name '*.java') || exit 1

run Task01 output.txt java -cp ../build/Task01 Task01Demo
run Task02 output.txt java -cp ../build/Task02 Task02Demo 130 30
run Task02 output_scanner.txt bash -c 'echo "130 30" | java -cp ../build/Task02 Task02Demo'
run Task03 output_facility.txt java -cp ../build/Task03 ParkingFacility
run Task03 output_feeslabs.txt java -cp ../build/Task03 FeeSlabs
run Task03 output_alt.txt java -cp ../build/Task03 AltFacility
run Task04 output.txt java -cp ../build/Task04 Task04Demo
run Task05 output.txt java -cp ../build/Task05 Task05Demo
run Task06_09_FeeDemo output.txt java -cp ../build/Task06_09_FeeDemo FeeDemo
run Task06_09_FeeDemo output_constructor_trace.txt java -cp ../build/Task06_09_FeeDemo ConstructorTrace
run Task07 output.txt java -cp ../build/Task07 OverrideDemo
run Task08 output.txt java -cp ../build/Task08 PolymorphismDemo
run Task09 output.txt java -cp ../build/Task09 InterfaceDemo
run Task10 output.txt java -cp ../build/Task10 com.campus.encaps.EncapsulationDemo

# Task 11 - original design
rm -rf build/Task11 && mkdir -p build/Task11
javac -d build/Task11 $(find Task11/src Task11/test Task11/bench -name '*.java') || exit 1
run Task11 output_app.txt bash -c 'java -cp ../build/Task11 com.campus.parking.app.ParkingApp < input/commands.txt'
run Task11 output_tests.txt java -cp ../build/Task11 com.campus.parking.test.ParkingTests
run Task11 output_bench.txt java -cp ../build/Task11 StorageBench

# Task 12 - adapted design (+ Task 11 tests re-run unchanged as a regression suite)
if [ -d Task12/src ]; then
  rm -rf build/Task12 build/Task12reg && mkdir -p build/Task12 build/Task12reg
  javac -d build/Task12 $(find Task12/src Task12/test -name '*.java') || exit 1
  javac -d build/Task12reg $(find Task12/src -name '*.java') $(find Task11/test -name '*.java') || exit 1
  run Task12 output_regression_task11_tests.txt java -cp ../build/Task12reg com.campus.parking.test.ParkingTests
  run Task12 output_new_tests.txt java -cp ../build/Task12 com.campus.parking.test.NewRequirementTests
  run Task12 output_app.txt bash -c 'java -cp ../build/Task12 com.campus.parking.app.ParkingApp < input/commands.txt'
fi
